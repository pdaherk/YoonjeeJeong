package ex20io;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class E10PrintWriterStream {

	public static void main(String[] args) throws IOException {

		PrintWriter out = new PrintWriter
				(new PrintWriter("src/ex20io/printf.txt"));
		
		out.printf("제 나이는 %d살 입니다. ", 9);
		out.print("노래부를 때 행복한 거 같아요");
		out.close();
		
		System.out.println("printf.txt가 생성되었습니다");
	}

}
